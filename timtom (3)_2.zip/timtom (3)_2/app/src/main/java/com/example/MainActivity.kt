package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.local.AppDatabase
import com.example.data.repository.ReelsRepository
import com.example.ui.screens.DiscoverScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.ReelsFeedScreen
import com.example.ui.screens.UploadVideoScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.TimTomBorder
import com.example.ui.theme.TimTomCardBg
import com.example.ui.theme.TimTomCrimson
import com.example.ui.theme.TimTomCyan
import com.example.ui.theme.TimTomDarkBg
import com.example.ui.theme.TimTomTextMuted
import com.example.ui.theme.TimTomTextSecondary
import com.example.ui.viewmodel.FeedViewMode
import com.example.ui.viewmodel.ReelsViewModel

enum class TimTomTab {
    REELS,
    DISCOVER,
    UPLOAD,
    PROFILE
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val database = AppDatabase.getInstance(applicationContext)
        val repository = ReelsRepository(database.reelDao())

        setContent {
            MyApplicationTheme {
                val viewModel: ReelsViewModel = viewModel(
                    factory = ReelsViewModel.Factory(repository)
                )

                TimTomApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun TimTomApp(viewModel: ReelsViewModel) {
    var currentTab by remember { mutableStateOf(TimTomTab.REELS) }

    // Android back navigation handler
    BackHandler(enabled = currentTab != TimTomTab.REELS) {
        currentTab = TimTomTab.REELS
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = TimTomDarkBg,
        bottomBar = {
            TimTomBottomNavigation(
                currentTab = currentTab,
                onTabSelected = { tab ->
                    currentTab = tab
                }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = innerPadding.calculateBottomPadding())
        ) {
            AnimatedContent(
                targetState = currentTab,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "screen_transition"
            ) { tab ->
                when (tab) {
                    TimTomTab.REELS -> {
                        ReelsFeedScreen(
                            viewModel = viewModel,
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    TimTomTab.DISCOVER -> {
                        DiscoverScreen(
                            viewModel = viewModel,
                            onSelectReel = {
                                viewModel.setFeedViewMode(FeedViewMode.IMMERSIVE_PAGER)
                                currentTab = TimTomTab.REELS
                            },
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    TimTomTab.UPLOAD -> {
                        UploadVideoScreen(
                            viewModel = viewModel,
                            onVideoPosted = {
                                currentTab = TimTomTab.REELS
                            },
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    TimTomTab.PROFILE -> {
                        ProfileScreen(
                            viewModel = viewModel,
                            onSelectReel = {
                                viewModel.setFeedViewMode(FeedViewMode.IMMERSIVE_PAGER)
                                currentTab = TimTomTab.REELS
                            },
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun TimTomBottomNavigation(
    currentTab: TimTomTab,
    onTabSelected: (TimTomTab) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(TimTomDarkBg)
            .navigationBarsPadding()
    ) {
        HorizontalDivider(color = TimTomBorder.copy(alpha = 0.5f), thickness = 0.8.dp)

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(58.dp)
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            // Home / Reels Tab
            BottomNavItem(
                label = "Reels",
                activeIcon = Icons.Filled.Home,
                inactiveIcon = Icons.Outlined.Home,
                isSelected = currentTab == TimTomTab.REELS,
                testTag = "nav_reels_tab",
                onClick = { onTabSelected(TimTomTab.REELS) }
            )

            // Discover Tab
            BottomNavItem(
                label = "Discover",
                activeIcon = Icons.Filled.Explore,
                inactiveIcon = Icons.Outlined.Explore,
                isSelected = currentTab == TimTomTab.DISCOVER,
                testTag = "nav_discover_tab",
                onClick = { onTabSelected(TimTomTab.DISCOVER) }
            )

            // Prominent TikTok/TimTom Central Upload Button
            Box(
                modifier = Modifier
                    .size(width = 48.dp, height = 34.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(
                                TimTomCyan,
                                TimTomCrimson
                            )
                        )
                    )
                    .clickable { onTabSelected(TimTomTab.UPLOAD) }
                    .testTag("nav_upload_button"),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(width = 42.dp, height = 28.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (currentTab == TimTomTab.UPLOAD) TimTomCrimson else Color.Black),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Upload Video",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            // Profile Tab
            BottomNavItem(
                label = "Profile",
                activeIcon = Icons.Filled.Person,
                inactiveIcon = Icons.Outlined.Person,
                isSelected = currentTab == TimTomTab.PROFILE,
                testTag = "nav_profile_tab",
                onClick = { onTabSelected(TimTomTab.PROFILE) }
            )
        }
    }
}

@Composable
fun BottomNavItem(
    label: String,
    activeIcon: ImageVector,
    inactiveIcon: ImageVector,
    isSelected: Boolean,
    testTag: String,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .testTag(testTag),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = if (isSelected) activeIcon else inactiveIcon,
            contentDescription = label,
            tint = if (isSelected) Color.White else TimTomTextMuted,
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = label,
            color = if (isSelected) Color.White else TimTomTextMuted,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
        )
    }
}
