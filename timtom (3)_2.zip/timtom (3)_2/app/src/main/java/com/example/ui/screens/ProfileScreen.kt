package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ReelEntity
import com.example.ui.theme.TimTomBorder
import com.example.ui.theme.TimTomCardBg
import com.example.ui.theme.TimTomCrimson
import com.example.ui.theme.TimTomDarkBg
import com.example.ui.theme.TimTomSurface
import com.example.ui.theme.TimTomTextMuted
import com.example.ui.theme.TimTomTextPrimary
import com.example.ui.theme.TimTomTextSecondary
import com.example.ui.viewmodel.ReelsViewModel

@Composable
fun ProfileScreen(
    viewModel: ReelsViewModel,
    onSelectReel: (ReelEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val allReels by viewModel.reels.collectAsState()
    val userUploadedReels by viewModel.userReels.collectAsState()

    var selectedTabIndex by remember { mutableIntStateOf(0) }
    var reelToDelete by remember { mutableStateOf<ReelEntity?>(null) }

    val likedReels = remember(allReels) { allReels.filter { it.isLiked } }
    val savedReels = remember(allReels) { allReels.filter { it.isSaved } }

    val displayedReels = when (selectedTabIndex) {
        0 -> userUploadedReels
        1 -> likedReels
        else -> savedReels
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(TimTomDarkBg)
            .statusBarsPadding()
            .navigationBarsPadding(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Top Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "Profile",
                color = TimTomTextPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )

            IconButton(
                onClick = {
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, "Check out my profile on TimTom! 🎥❤️")
                    }
                    context.startActivity(Intent.createChooser(shareIntent, "Share TimTom Profile"))
                },
                modifier = Modifier.testTag("share_profile_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Share,
                    contentDescription = "Share Profile",
                    tint = Color.White
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Avatar
        Box(
            modifier = Modifier
                .size(86.dp)
                .clip(CircleShape)
                .background(TimTomCardBg)
                .border(2.dp, TimTomCrimson, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Person,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(46.dp)
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Name & Handle
        Text(
            text = "TimTom User",
            color = TimTomTextPrimary,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "@timtom_user",
            color = TimTomTextSecondary,
            fontSize = 13.sp
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Stats Row (Following, Followers, Likes)
        Row(
            modifier = Modifier.fillMaxWidth(0.85f),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            ProfileStatItem(count = "184", label = "Following")
            ProfileStatItem(count = "2.4K", label = "Followers")
            ProfileStatItem(
                count = "${userUploadedReels.sumOf { it.likesCount } + 120}",
                label = "Likes"
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Bio
        Text(
            text = "Creating & sharing videos on TimTom ❤️✨\nLiving in the moment 🎥",
            color = TimTomTextSecondary,
            fontSize = 13.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 32.dp)
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Tab Row (My Videos, Liked, Saved)
        TabRow(
            selectedTabIndex = selectedTabIndex,
            containerColor = TimTomDarkBg,
            contentColor = TimTomCrimson,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                    color = TimTomCrimson
                )
            },
            divider = { HorizontalDivider(color = TimTomBorder, thickness = 0.8.dp) }
        ) {
            Tab(
                selected = selectedTabIndex == 0,
                onClick = { selectedTabIndex = 0 },
                icon = {
                    Icon(
                        imageVector = Icons.Default.VideoLibrary,
                        contentDescription = "My Videos",
                        tint = if (selectedTabIndex == 0) TimTomCrimson else TimTomTextSecondary
                    )
                },
                text = {
                    Text(
                        text = "My Videos (${userUploadedReels.size})",
                        fontSize = 12.sp,
                        color = if (selectedTabIndex == 0) TimTomCrimson else TimTomTextSecondary
                    )
                },
                modifier = Modifier.testTag("tab_my_videos")
            )

            Tab(
                selected = selectedTabIndex == 1,
                onClick = { selectedTabIndex = 1 },
                icon = {
                    Icon(
                        imageVector = Icons.Default.Favorite,
                        contentDescription = "Liked",
                        tint = if (selectedTabIndex == 1) TimTomCrimson else TimTomTextSecondary
                    )
                },
                text = {
                    Text(
                        text = "Liked (${likedReels.size})",
                        fontSize = 12.sp,
                        color = if (selectedTabIndex == 1) TimTomCrimson else TimTomTextSecondary
                    )
                },
                modifier = Modifier.testTag("tab_liked_videos")
            )

            Tab(
                selected = selectedTabIndex == 2,
                onClick = { selectedTabIndex = 2 },
                icon = {
                    Icon(
                        imageVector = Icons.Default.Bookmark,
                        contentDescription = "Saved",
                        tint = if (selectedTabIndex == 2) TimTomCrimson else TimTomTextSecondary
                    )
                },
                text = {
                    Text(
                        text = "Saved (${savedReels.size})",
                        fontSize = 12.sp,
                        color = if (selectedTabIndex == 2) TimTomCrimson else TimTomTextSecondary
                    )
                },
                modifier = Modifier.testTag("tab_saved_videos")
            )
        }

        // Grid Content
        if (displayedReels.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = if (selectedTabIndex == 0) "🎬" else if (selectedTabIndex == 1) "❤️" else "🔖",
                        fontSize = 36.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (selectedTabIndex == 0) "No videos posted yet" else if (selectedTabIndex == 1) "No liked videos yet" else "No saved videos yet",
                        color = TimTomTextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (selectedTabIndex == 0) "Upload your first video to start building your profile!" else "Explore reels and interact with creators!",
                        color = TimTomTextSecondary,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 32.dp)
                    )
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                items(displayedReels, key = { it.id }) { reel ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(9f / 16f)
                            .clip(RoundedCornerShape(6.dp))
                            .background(TimTomCardBg)
                            .clickable { onSelectReel(reel) }
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(TimTomSurface),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = TimTomCrimson,
                                modifier = Modifier.size(32.dp)
                            )
                        }

                        // Bottom likes indicator
                        Row(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Favorite,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = "${reel.likesCount}",
                                color = Color.White,
                                fontSize = 11.sp
                            )
                        }

                        // Delete option for user's own uploads
                        if (selectedTabIndex == 0) {
                            IconButton(
                                onClick = { reelToDelete = reel },
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(2.dp)
                                    .size(28.dp)
                                    .clip(CircleShape)
                                    .background(Color.Black.copy(alpha = 0.6f))
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "Delete",
                                    tint = Color.White,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Delete Confirmation Dialog
        if (reelToDelete != null) {
            AlertDialog(
                onDismissRequest = { reelToDelete = null },
                containerColor = TimTomSurface,
                title = {
                    Text(
                        text = "Delete Reel?",
                        color = TimTomTextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                },
                text = {
                    Text(
                        text = "Are you sure you want to remove this video from TimTom?",
                        color = TimTomTextSecondary
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            reelToDelete?.let { viewModel.deleteReel(it) }
                            reelToDelete = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = TimTomCrimson)
                    ) {
                        Text("Delete", color = Color.White)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { reelToDelete = null }) {
                        Text("Cancel", color = TimTomTextSecondary)
                    }
                }
            )
        }
    }
}

@Composable
fun ProfileStatItem(count: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = count,
            color = TimTomTextPrimary,
            fontSize = 17.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = label,
            color = TimTomTextSecondary,
            fontSize = 12.sp
        )
    }
}
