package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.CommentEntity
import com.example.data.model.ReelEntity
import com.example.data.repository.ReelsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class FeedViewMode {
    IMMERSIVE_PAGER, // Fullscreen swipeable vertical pager
    CARD_FEED        // Card-based feed like original web prototype
}

class ReelsViewModel(
    private val repository: ReelsRepository
) : ViewModel() {

    val reels: StateFlow<List<ReelEntity>> = repository.allReels
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val userReels: StateFlow<List<ReelEntity>> = repository.userUploadedReels
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _feedViewMode = MutableStateFlow(FeedViewMode.IMMERSIVE_PAGER)
    val feedViewMode: StateFlow<FeedViewMode> = _feedViewMode.asStateFlow()

    private val _selectedReelForComments = MutableStateFlow<ReelEntity?>(null)
    val selectedReelForComments: StateFlow<ReelEntity?> = _selectedReelForComments.asStateFlow()

    private val _activeComments = MutableStateFlow<List<CommentEntity>>(emptyList())
    val activeComments: StateFlow<List<CommentEntity>> = _activeComments.asStateFlow()

    private val _currentReelIndex = MutableStateFlow(0)
    val currentReelIndex: StateFlow<Int> = _currentReelIndex.asStateFlow()

    private val _isUploading = MutableStateFlow(false)
    val isUploading: StateFlow<Boolean> = _isUploading.asStateFlow()

    private val _uploadSuccessMessage = MutableStateFlow<String?>(null)
    val uploadSuccessMessage: StateFlow<String?> = _uploadSuccessMessage.asStateFlow()

    init {
        viewModelScope.launch {
            repository.initializeSeedDataIfNeeded()
        }
    }

    fun setFeedViewMode(mode: FeedViewMode) {
        _feedViewMode.value = mode
    }

    fun setCurrentReelIndex(index: Int) {
        _currentReelIndex.value = index
    }

    fun toggleLike(reel: ReelEntity) {
        viewModelScope.launch {
            repository.toggleLike(reel)
        }
    }

    fun toggleBookmark(reel: ReelEntity) {
        viewModelScope.launch {
            repository.toggleBookmark(reel)
        }
    }

    fun shareReel(reel: ReelEntity) {
        viewModelScope.launch {
            repository.incrementShare(reel)
        }
    }

    fun openComments(reel: ReelEntity) {
        _selectedReelForComments.value = reel
        viewModelScope.launch {
            repository.getCommentsForReel(reel.id).collect { comments ->
                _activeComments.value = comments
            }
        }
    }

    fun closeComments() {
        _selectedReelForComments.value = null
        _activeComments.value = emptyList()
    }

    fun addComment(text: String, authorName: String = "TimTom User") {
        val reel = _selectedReelForComments.value ?: return
        viewModelScope.launch {
            repository.addComment(
                reelId = reel.id,
                authorName = authorName,
                text = text
            )
        }
    }

    fun postVideo(
        videoUri: String,
        caption: String,
        creatorName: String = "TimTom User",
        onSuccess: () -> Unit = {}
    ) {
        viewModelScope.launch {
            _isUploading.value = true
            try {
                repository.postUserVideo(
                    videoUri = videoUri,
                    caption = caption,
                    creatorName = creatorName
                )
                _uploadSuccessMessage.value = "Video posted to TimTom feed! ❤️"
                _currentReelIndex.value = 0
                onSuccess()
            } finally {
                _isUploading.value = false
            }
        }
    }

    fun clearUploadSuccessMessage() {
        _uploadSuccessMessage.value = null
    }

    fun deleteReel(reel: ReelEntity) {
        viewModelScope.launch {
            repository.deleteReel(reel)
        }
    }

    class Factory(private val repository: ReelsRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(ReelsViewModel::class.java)) {
                return ReelsViewModel(repository) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}
