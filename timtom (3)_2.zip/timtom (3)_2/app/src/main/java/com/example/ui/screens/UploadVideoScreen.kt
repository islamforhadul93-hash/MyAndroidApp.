package com.example.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayCircleOutline
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.VideoPlayerView
import com.example.ui.theme.TimTomBorder
import com.example.ui.theme.TimTomCardBg
import com.example.ui.theme.TimTomCrimson
import com.example.ui.theme.TimTomDarkBg
import com.example.ui.theme.TimTomSurface
import com.example.ui.theme.TimTomTextMuted
import com.example.ui.theme.TimTomTextPrimary
import com.example.ui.theme.TimTomTextSecondary
import com.example.ui.viewmodel.ReelsViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun UploadVideoScreen(
    viewModel: ReelsViewModel,
    onVideoPosted: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isUploading by viewModel.isUploading.collectAsState()

    var selectedVideoUri by remember { mutableStateOf<String?>(null) }
    var captionText by remember { mutableStateOf("My New Video ❤️") }
    var creatorNameText by remember { mutableStateOf("TimTom User") }

    val presetTags = listOf("#fyp", "#viral", "#timtom", "#trending", "#dance", "#vibes", "#comedy")

    // Android zero-permission Photo & Video Picker
    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedVideoUri = uri.toString()
            Toast.makeText(context, "Video selected! 🎬", Toast.LENGTH_SHORT).show()
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(TimTomDarkBg)
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Header matching prototype
        Text(
            text = "❤️ TimTom Studio",
            color = TimTomCrimson,
            fontSize = 24.sp,
            fontWeight = FontWeight.Black
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Upload Your Video",
            color = TimTomTextPrimary,
            fontSize = 19.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Share your moments with the TimTom community",
            color = TimTomTextSecondary,
            fontSize = 13.sp,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Video Selection / Preview Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .border(1.dp, if (selectedVideoUri != null) TimTomCrimson else TimTomBorder, RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = TimTomSurface)
        ) {
            if (selectedVideoUri != null) {
                // Video Preview Box
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(280.dp)
                        .background(Color.Black)
                ) {
                    VideoPlayerView(
                        videoUri = selectedVideoUri!!,
                        isActive = true,
                        modifier = Modifier.fillMaxSize()
                    )

                    // Remove video button
                    IconButton(
                        onClick = { selectedVideoUri = null },
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(8.dp)
                            .clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.6f))
                            .testTag("remove_selected_video_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Remove video",
                            tint = Color.White
                        )
                    }

                    // Selected confirmation tag
                    Row(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(12.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.Black.copy(alpha = 0.7f))
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = TimTomCrimson,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Video Ready to Post",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            } else {
                // Empty State Picker
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(68.dp)
                            .clip(CircleShape)
                            .background(TimTomCardBg),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Videocam,
                            contentDescription = null,
                            tint = TimTomCrimson,
                            modifier = Modifier.size(36.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "Choose a video to post",
                        color = TimTomTextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Supports MP4, WebM, and standard video files",
                        color = TimTomTextMuted,
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Primary Button: Device Gallery Picker
                    Button(
                        onClick = {
                            videoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = TimTomCrimson),
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier
                            .fillMaxWidth(0.85f)
                            .testTag("select_video_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.VideoLibrary,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Choose from Device",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Secondary Fast Option: Demo video for instant emulator testing
                    Button(
                        onClick = {
                            selectedVideoUri = "https://test-videos.co.uk/vids/jellyfish/mp4/h264/720/Jellyfish_720_10s_1MB.mp4"
                            Toast.makeText(context, "Loaded test video clip! 🚀", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = TimTomCardBg),
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier.testTag("load_demo_clip_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = TimTomCrimson,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Use Sample Clip (Fast Test)",
                            color = TimTomTextSecondary,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Caption Input
        Column(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = "Caption",
                color = TimTomTextPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedTextField(
                value = captionText,
                onValueChange = { captionText = it },
                placeholder = {
                    Text(
                        text = "Write a catchy caption...",
                        color = TimTomTextMuted
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("caption_input_field"),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = TimTomSurface,
                    unfocusedContainerColor = TimTomSurface,
                    focusedBorderColor = TimTomCrimson,
                    unfocusedBorderColor = TimTomBorder,
                    focusedTextColor = TimTomTextPrimary,
                    unfocusedTextColor = TimTomTextPrimary
                ),
                maxLines = 3
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Hashtags Shortcut FlowRow
        Column(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = "Quick Hashtags",
                color = TimTomTextSecondary,
                fontSize = 13.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                presetTags.forEach { tag ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(TimTomCardBg)
                            .clickable {
                                if (!captionText.contains(tag)) {
                                    captionText = "$captionText $tag"
                                }
                            }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = tag,
                            color = TimTomCrimson,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Creator Name Input
        Column(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = "Creator Name",
                color = TimTomTextPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedTextField(
                value = creatorNameText,
                onValueChange = { creatorNameText = it },
                placeholder = {
                    Text(
                        text = "Enter your display name",
                        color = TimTomTextMuted
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("creator_name_input_field"),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = TimTomSurface,
                    unfocusedContainerColor = TimTomSurface,
                    focusedBorderColor = TimTomCrimson,
                    unfocusedBorderColor = TimTomBorder,
                    focusedTextColor = TimTomTextPrimary,
                    unfocusedTextColor = TimTomTextPrimary
                ),
                singleLine = true
            )
        }

        Spacer(modifier = Modifier.height(28.dp))

        // "Post Video" Button matching prototype
        Button(
            onClick = {
                val uri = selectedVideoUri
                if (uri.isNullOrBlank()) {
                    Toast.makeText(context, "Please select a video!", Toast.LENGTH_SHORT).show()
                    return@Button
                }

                viewModel.postVideo(
                    videoUri = uri,
                    caption = captionText,
                    creatorName = creatorNameText,
                    onSuccess = {
                        Toast.makeText(context, "Posted successfully! ❤️", Toast.LENGTH_LONG).show()
                        onVideoPosted()
                    }
                )
            },
            enabled = !isUploading,
            colors = ButtonDefaults.buttonColors(containerColor = TimTomCrimson),
            shape = RoundedCornerShape(26.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .testTag("post_video_button")
        ) {
            if (isUploading) {
                CircularProgressIndicator(
                    color = Color.White,
                    strokeWidth = 2.5.dp,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = "Posting to TimTom...",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            } else {
                Icon(
                    imageVector = Icons.Default.PlayCircleOutline,
                    contentDescription = null,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Post Video",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }
    }
}
