package com.example.ui.screens

import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Comment
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ViewDay
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.ReelEntity
import com.example.ui.components.CommentsBottomSheet
import com.example.ui.components.VideoPlayerView
import com.example.ui.theme.TimTomBorder
import com.example.ui.theme.TimTomCardBg
import com.example.ui.theme.TimTomCrimson
import com.example.ui.theme.TimTomDarkBg
import com.example.ui.theme.TimTomTextMuted
import com.example.ui.theme.TimTomTextPrimary
import com.example.ui.theme.TimTomTextSecondary
import com.example.ui.viewmodel.FeedViewMode
import com.example.ui.viewmodel.ReelsViewModel

@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)
@Composable
fun ReelsFeedScreen(
    viewModel: ReelsViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val reels by viewModel.reels.collectAsState()
    val viewMode by viewModel.feedViewMode.collectAsState()
    val selectedReelForComments by viewModel.selectedReelForComments.collectAsState()
    val activeComments by viewModel.activeComments.collectAsState()

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(TimTomDarkBg)
    ) {
        if (reels.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = "❤️", fontSize = 48.sp)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Loading TimTom Reels...",
                        color = TimTomTextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        } else if (viewMode == FeedViewMode.IMMERSIVE_PAGER) {
            // TikTok / Reels Fullscreen Pager
            val pagerState = rememberPagerState(
                initialPage = 0,
                pageCount = { reels.size }
            )

            LaunchedEffect(pagerState) {
                snapshotFlow { pagerState.currentPage }.collect { page ->
                    viewModel.setCurrentReelIndex(page)
                }
            }

            VerticalPager(
                state = pagerState,
                modifier = Modifier.fillMaxSize()
            ) { page ->
                val reel = reels[page]
                val isActive = page == pagerState.currentPage

                Box(modifier = Modifier.fillMaxSize()) {
                    VideoPlayerView(
                        videoUri = reel.videoUri,
                        isActive = isActive,
                        modifier = Modifier.fillMaxSize(),
                        onDoubleTap = { viewModel.toggleLike(reel) }
                    )

                    // Top Gradient Shadow
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                            .align(Alignment.TopCenter)
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        Color.Black.copy(alpha = 0.75f),
                                        Color.Transparent
                                    )
                                )
                            )
                    )

                    // Bottom Gradient Shadow for legible captions
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(260.dp)
                            .align(Alignment.BottomCenter)
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        Color.Transparent,
                                        Color.Black.copy(alpha = 0.85f)
                                    )
                                )
                            )
                    )

                    // Right Action Rail (Avatar, Like, Comment, Bookmark, Share, Vinyl)
                    ActionRail(
                        reel = reel,
                        onLike = { viewModel.toggleLike(reel) },
                        onComment = { viewModel.openComments(reel) },
                        onBookmark = { viewModel.toggleBookmark(reel) },
                        onShare = {
                            viewModel.shareReel(reel)
                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_SUBJECT, "TimTom Video")
                                putExtra(
                                    Intent.EXTRA_TEXT,
                                    "Watch '${reel.caption}' on TimTom! 🎥❤️ #TimTom"
                                )
                            }
                            context.startActivity(Intent.createChooser(shareIntent, "Share TimTom Video"))
                        },
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(end = 12.dp, bottom = 80.dp)
                    )

                    // Bottom Left Caption & Creator Info
                    BottomVideoInfo(
                        reel = reel,
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(start = 16.dp, end = 90.dp, bottom = 80.dp)
                    )
                }
            }
        } else {
            // Card Feed Mode (Direct mirror of original web prototype!)
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(top = 70.dp, bottom = 70.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(reels, key = { it.id }) { reel ->
                    PrototypeVideoCard(
                        reel = reel,
                        onLike = { viewModel.toggleLike(reel) },
                        onComment = { viewModel.openComments(reel) },
                        onShare = {
                            viewModel.shareReel(reel)
                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_SUBJECT, "TimTom Video")
                                putExtra(
                                    Intent.EXTRA_TEXT,
                                    "Watch '${reel.caption}' on TimTom! 🎥❤️"
                                )
                            }
                            context.startActivity(Intent.createChooser(shareIntent, "Share TimTom Video"))
                        }
                    )
                }
            }
        }

        // Header overlay with "❤️ TimTom" and view mode toggle
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "❤️ TimTom",
                    color = TimTomCrimson,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.testTag("app_header_title")
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                // View Mode Toggle (Pager vs Card Feed)
                IconButton(
                    onClick = {
                        val newMode = if (viewMode == FeedViewMode.IMMERSIVE_PAGER) {
                            FeedViewMode.CARD_FEED
                        } else {
                            FeedViewMode.IMMERSIVE_PAGER
                        }
                        viewModel.setFeedViewMode(newMode)
                    },
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.5f))
                        .testTag("view_mode_toggle_button")
                ) {
                    Icon(
                        imageVector = if (viewMode == FeedViewMode.IMMERSIVE_PAGER) Icons.Default.ViewDay else Icons.Default.GridView,
                        contentDescription = "Toggle View Mode",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        // Comments Bottom Sheet
        if (selectedReelForComments != null) {
            CommentsBottomSheet(
                comments = activeComments,
                sheetState = sheetState,
                onDismissRequest = { viewModel.closeComments() },
                onSendComment = { text -> viewModel.addComment(text) }
            )
        }
    }
}

/**
 * Right Action Rail (Vertical TikTok/Reels buttons)
 */
@Composable
fun ActionRail(
    reel: ReelEntity,
    onLike: () -> Unit,
    onComment: () -> Unit,
    onBookmark: () -> Unit,
    onShare: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Creator Avatar with Follow button
        Box(
            modifier = Modifier.size(52.dp),
            contentAlignment = Alignment.TopCenter
        ) {
            if (reel.creatorAvatar.isNotBlank()) {
                AsyncImage(
                    model = reel.creatorAvatar,
                    contentDescription = reel.creatorName,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .border(1.5.dp, Color.White, CircleShape)
                )
            } else {
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(TimTomCardBg)
                        .border(1.5.dp, TimTomCrimson, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            // Follow Plus Badge
            Box(
                modifier = Modifier
                    .size(20.dp)
                    .align(Alignment.BottomCenter)
                    .clip(CircleShape)
                    .background(TimTomCrimson),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Follow",
                    tint = Color.White,
                    modifier = Modifier.size(14.dp)
                )
            }
        }

        // Like Button
        ActionButton(
            icon = if (reel.isLiked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
            iconTint = if (reel.isLiked) TimTomCrimson else Color.White,
            count = formatCount(reel.likesCount),
            contentDescription = "Like",
            testTag = "like_reel_button",
            onClick = onLike
        )

        // Comment Button
        ActionButton(
            icon = Icons.Default.Comment,
            iconTint = Color.White,
            count = formatCount(reel.commentsCount),
            contentDescription = "Comments",
            testTag = "comment_reel_button",
            onClick = onComment
        )

        // Bookmark Button
        ActionButton(
            icon = if (reel.isSaved) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
            iconTint = if (reel.isSaved) TimTomCrimson else Color.White,
            count = if (reel.isSaved) "Saved" else "Save",
            contentDescription = "Bookmark",
            testTag = "bookmark_reel_button",
            onClick = onBookmark
        )

        // Share Button
        ActionButton(
            icon = Icons.Default.Share,
            iconTint = Color.White,
            count = formatCount(reel.sharesCount),
            contentDescription = "Share",
            testTag = "share_reel_button",
            onClick = onShare
        )

        // Spinning Music Disk
        SpinningMusicDisk(soundTitle = reel.soundTitle)
    }
}

@Composable
fun ActionButton(
    icon: ImageVector,
    iconTint: Color,
    count: String,
    contentDescription: String,
    testTag: String,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable(onClick = onClick)
            .testTag(testTag)
            .padding(4.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = iconTint,
            modifier = Modifier.size(32.dp)
        )
        Spacer(modifier = Modifier.height(3.dp))
        Text(
            text = count,
            color = Color.White,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
fun SpinningMusicDisk(soundTitle: String) {
    val infiniteTransition = rememberInfiniteTransition(label = "music_disk")
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    Box(
        modifier = Modifier
            .size(46.dp)
            .clip(CircleShape)
            .background(Color.Black.copy(alpha = 0.8f))
            .border(1.5.dp, TimTomBorder, CircleShape)
            .rotate(rotation),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .size(24.dp)
                .clip(CircleShape)
                .background(TimTomCrimson),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.MusicNote,
                contentDescription = soundTitle,
                tint = Color.White,
                modifier = Modifier.size(14.dp)
            )
        }
    }
}

@Composable
fun BottomVideoInfo(
    reel: ReelEntity,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier) {
        // Creator Name & Handle
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = reel.creatorName,
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = reel.creatorHandle,
                color = TimTomTextSecondary,
                fontSize = 13.sp
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Caption
        Text(
            text = reel.caption,
            color = Color.White,
            fontSize = 14.sp,
            lineHeight = 18.sp,
            maxLines = 3,
            overflow = TextOverflow.Ellipsis
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Sound Marquee
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .background(Color.Black.copy(alpha = 0.4f))
                .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            Icon(
                imageVector = Icons.Default.MusicNote,
                contentDescription = null,
                tint = TimTomCrimson,
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = reel.soundTitle,
                color = Color.White,
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

/**
 * Direct recreation of the original Web Prototype's `.video-card`
 */
@Composable
fun PrototypeVideoCard(
    reel: ReelEntity,
    onLike: () -> Unit,
    onComment: () -> Unit,
    onShare: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .clip(RoundedCornerShape(14.dp))
            .testTag("prototype_video_card_${reel.id}"),
        colors = CardDefaults.cardColors(containerColor = TimTomCardBg),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Video Player
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(420.dp)
                    .background(Color.Black)
            ) {
                VideoPlayerView(
                    videoUri = reel.videoUri,
                    isActive = true,
                    modifier = Modifier.fillMaxSize(),
                    onDoubleTap = onLike
                )
            }

            // Info Section (.info in CSS)
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = reel.creatorName,
                    color = Color.White,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = reel.caption,
                    color = TimTomTextSecondary,
                    fontSize = 14.sp
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Action Buttons Row (Like, Comment, Share)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Like button matching: <button class="like">❤️ Like <span>0</span></button>
                    Button(
                        onClick = onLike,
                        colors = ButtonDefaults.buttonColors(containerColor = TimTomCrimson),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.testTag("card_like_button")
                    ) {
                        Text(
                            text = "❤️ Like ${reel.likesCount}",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Comment button matching: <button class="comment">💬 Comment</button>
                    Button(
                        onClick = onComment,
                        colors = ButtonDefaults.buttonColors(containerColor = TimTomCrimson),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.testTag("card_comment_button")
                    ) {
                        Text(
                            text = "💬 Comment",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Share button matching: <button class="share">📤 Share</button>
                    Button(
                        onClick = onShare,
                        colors = ButtonDefaults.buttonColors(containerColor = TimTomCrimson),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.testTag("card_share_button")
                    ) {
                        Text(
                            text = "📤 Share",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

fun formatCount(count: Int): String {
    return when {
        count >= 1_000_000 -> String.format("%.1fM", count / 1_000_000.0)
        count >= 1_000 -> String.format("%.1fK", count / 1_000.0)
        else -> count.toString()
    }
}
