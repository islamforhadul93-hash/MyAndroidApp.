package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// TimTom Signature Brand Colors
val TimTomCrimson = Color(0xFFFF3155)      // #ff3155 from the user's web prototype
val TimTomCrimsonDark = Color(0xFFD61A3D)
val TimTomCrimsonLight = Color(0xFFFF6584)
val TimTomCyan = Color(0xFF00F2FE)
val TimTomDarkBg = Color(0xFF111111)        // #111 from prototype
val TimTomBlack = Color(0xFF000000)
val TimTomCardBg = Color(0xFF222222)        // #222 from prototype
val TimTomSurface = Color(0xFF1A1A1E)
val TimTomSurfaceVariant = Color(0xFF2B2B32)
val TimTomBorder = Color(0xFF33333A)

val TimTomTextPrimary = Color(0xFFFFFFFF)
val TimTomTextSecondary = Color(0xFFB0B0BC)
val TimTomTextMuted = Color(0xFF70707E)

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)
