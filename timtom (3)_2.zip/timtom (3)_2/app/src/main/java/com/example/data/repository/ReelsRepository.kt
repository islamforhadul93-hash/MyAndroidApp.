package com.example.data.repository

import com.example.data.local.ReelDao
import com.example.data.model.CommentEntity
import com.example.data.model.ReelEntity
import kotlinx.coroutines.flow.Flow
import java.util.UUID

class ReelsRepository(private val reelDao: ReelDao) {

    val allReels: Flow<List<ReelEntity>> = reelDao.getAllReels()
    val userUploadedReels: Flow<List<ReelEntity>> = reelDao.getUserUploadedReels()

    suspend fun initializeSeedDataIfNeeded() {
        val existing = reelDao.getAllReelsList()
        if (existing.isEmpty()) {
            val starterReels = listOf(
                ReelEntity(
                    id = "seed-1",
                    videoUri = "https://test-videos.co.uk/vids/bigbuckbunny/mp4/h264/720/Big_Buck_Bunny_720_10s_1MB.mp4",
                    thumbnailUrl = "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=600&auto=format&fit=crop&q=80",
                    creatorName = "TimTom Creator",
                    creatorHandle = "@timtom_official",
                    creatorAvatar = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80",
                    caption = "Welcome to TimTom Reels! 🔥 Express yourself and upload your best moments! ❤️ #timtom #viral #explore",
                    soundTitle = "TimTom Official Soundtrack - Energetic Beats",
                    likesCount = 1420,
                    commentsCount = 28,
                    sharesCount = 64,
                    isLiked = false,
                    isSaved = false,
                    isUserUploaded = false,
                    createdAt = System.currentTimeMillis() - 3600000
                ),
                ReelEntity(
                    id = "seed-2",
                    videoUri = "https://test-videos.co.uk/vids/jellyfish/mp4/h264/720/Jellyfish_720_10s_1MB.mp4",
                    thumbnailUrl = "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=600&auto=format&fit=crop&q=80",
                    creatorName = "Travel Vibes",
                    creatorHandle = "@wanderlust_diaries",
                    creatorAvatar = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80",
                    caption = "Escaping to paradise! 🌊 Where would you rather be right now? ✈️🌴 #travel #wanderlust #paradise",
                    soundTitle = "Summer Chill - Tropical Vibes",
                    likesCount = 3890,
                    commentsCount = 112,
                    sharesCount = 210,
                    isLiked = false,
                    isSaved = true,
                    isUserUploaded = false,
                    createdAt = System.currentTimeMillis() - 7200000
                ),
                ReelEntity(
                    id = "seed-3",
                    videoUri = "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4",
                    thumbnailUrl = "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=600&auto=format&fit=crop&q=80",
                    creatorName = "Neon Beats",
                    creatorHandle = "@neon_dancer",
                    creatorAvatar = "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&auto=format&fit=crop&q=80",
                    caption = "Friday night dance energy! 💃 Tag someone who needs to see this choreo! #dance #energy #groove",
                    soundTitle = "Club Anthem 2026 - DJ Neon",
                    likesCount = 5620,
                    commentsCount = 230,
                    sharesCount = 450,
                    isLiked = false,
                    isSaved = false,
                    isUserUploaded = false,
                    createdAt = System.currentTimeMillis() - 10800000
                ),
                ReelEntity(
                    id = "seed-4",
                    videoUri = "https://test-videos.co.uk/vids/sintel/mp4/h264/720/Sintel_720_10s_1MB.mp4",
                    thumbnailUrl = "https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=600&auto=format&fit=crop&q=80",
                    creatorName = "Nature Explorer",
                    creatorHandle = "@wildlife_stories",
                    creatorAvatar = "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&auto=format&fit=crop&q=80",
                    caption = "Pure joy in the wild! ✨ Wait till the end for the surprise! 🦊 #nature #animals #joy",
                    soundTitle = "Acoustic Melody - Morning Serenade",
                    likesCount = 8940,
                    commentsCount = 345,
                    sharesCount = 612,
                    isLiked = false,
                    isSaved = false,
                    isUserUploaded = false,
                    createdAt = System.currentTimeMillis() - 14400000
                )
            )
            reelDao.insertReels(starterReels)

            // Seed initial sample comments for starter reels
            val seedComments = listOf(
                CommentEntity(
                    id = UUID.randomUUID().toString(),
                    reelId = "seed-1",
                    authorName = "Alex Rivera",
                    authorAvatar = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&auto=format&fit=crop&q=80",
                    text = "Welcome to TimTom! The UI is looking super slick! 🔥❤️",
                    timestamp = System.currentTimeMillis() - 1800000,
                    likesCount = 14
                ),
                CommentEntity(
                    id = UUID.randomUUID().toString(),
                    reelId = "seed-1",
                    authorName = "Chloe Bennett",
                    authorAvatar = "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=100&auto=format&fit=crop&q=80",
                    text = "Love the heart animations! Can't wait to post my videos 😍",
                    timestamp = System.currentTimeMillis() - 900000,
                    likesCount = 8
                ),
                CommentEntity(
                    id = UUID.randomUUID().toString(),
                    reelId = "seed-2",
                    authorName = "Liam Vance",
                    authorAvatar = "https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=100&auto=format&fit=crop&q=80",
                    text = "Take me there right now please! 🏝️✈️",
                    timestamp = System.currentTimeMillis() - 3600000,
                    likesCount = 22
                )
            )
            seedComments.forEach { reelDao.insertComment(it) }
        } else {
            // Repair any old records with broken URL domain
            existing.forEach { reel ->
                if (reel.videoUri.contains("commondatastorage.googleapis.com")) {
                    val fixedUri = when (reel.id) {
                        "seed-1" -> "https://test-videos.co.uk/vids/bigbuckbunny/mp4/h264/720/Big_Buck_Bunny_720_10s_1MB.mp4"
                        "seed-2" -> "https://test-videos.co.uk/vids/jellyfish/mp4/h264/720/Jellyfish_720_10s_1MB.mp4"
                        "seed-3" -> "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4"
                        "seed-4" -> "https://test-videos.co.uk/vids/sintel/mp4/h264/720/Sintel_720_10s_1MB.mp4"
                        else -> "https://test-videos.co.uk/vids/bigbuckbunny/mp4/h264/720/Big_Buck_Bunny_720_10s_1MB.mp4"
                    }
                    reelDao.updateReel(reel.copy(videoUri = fixedUri))
                }
            }
        }
    }

    suspend fun postUserVideo(
        videoUri: String,
        caption: String,
        creatorName: String = "TimTom User",
        soundTitle: String = "Original Sound - $creatorName"
    ): ReelEntity {
        val newReel = ReelEntity(
            id = UUID.randomUUID().toString(),
            videoUri = videoUri,
            thumbnailUrl = "",
            creatorName = creatorName.ifBlank { "TimTom User" },
            creatorHandle = "@${(creatorName.ifBlank { "timtom_user" }).lowercase().replace(" ", "_")}",
            creatorAvatar = "",
            caption = caption.ifBlank { "My New Video ❤️" },
            soundTitle = soundTitle,
            likesCount = 0,
            commentsCount = 0,
            sharesCount = 0,
            isLiked = false,
            isSaved = false,
            isUserUploaded = true,
            createdAt = System.currentTimeMillis()
        )
        reelDao.insertReel(newReel)
        return newReel
    }

    suspend fun toggleLike(reel: ReelEntity) {
        val newIsLiked = !reel.isLiked
        val newLikesCount = if (newIsLiked) reel.likesCount + 1 else maxOf(0, reel.likesCount - 1)
        val updated = reel.copy(isLiked = newIsLiked, likesCount = newLikesCount)
        reelDao.updateReel(updated)
    }

    suspend fun toggleBookmark(reel: ReelEntity) {
        val updated = reel.copy(isSaved = !reel.isSaved)
        reelDao.updateReel(updated)
    }

    suspend fun incrementShare(reel: ReelEntity) {
        val updated = reel.copy(sharesCount = reel.sharesCount + 1)
        reelDao.updateReel(updated)
    }

    fun getCommentsForReel(reelId: String): Flow<List<CommentEntity>> {
        return reelDao.getCommentsForReel(reelId)
    }

    suspend fun addComment(reelId: String, authorName: String, text: String) {
        val comment = CommentEntity(
            id = UUID.randomUUID().toString(),
            reelId = reelId,
            authorName = authorName.ifBlank { "TimTom User" },
            text = text,
            timestamp = System.currentTimeMillis(),
            likesCount = 0
        )
        reelDao.insertComment(comment)

        val reel = reelDao.getReelById(reelId)
        if (reel != null) {
            val updated = reel.copy(commentsCount = reel.commentsCount + 1)
            reelDao.updateReel(updated)
        }
    }

    suspend fun deleteReel(reel: ReelEntity) {
        reelDao.deleteReel(reel)
        reelDao.deleteCommentsForReel(reel.id)
    }
}
