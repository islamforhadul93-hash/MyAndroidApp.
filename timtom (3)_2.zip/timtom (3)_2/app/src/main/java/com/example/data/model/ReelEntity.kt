package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "reels")
data class ReelEntity(
    @PrimaryKey
    val id: String,
    val videoUri: String,
    val thumbnailUrl: String = "",
    val creatorName: String = "TimTom User",
    val creatorHandle: String = "@timtom_user",
    val creatorAvatar: String = "",
    val caption: String = "My New Video ❤️",
    val soundTitle: String = "Original Sound - TimTom Vibes",
    val likesCount: Int = 0,
    val commentsCount: Int = 0,
    val sharesCount: Int = 0,
    val isLiked: Boolean = false,
    val isSaved: Boolean = false,
    val isUserUploaded: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "comments")
data class CommentEntity(
    @PrimaryKey
    val id: String,
    val reelId: String,
    val authorName: String = "TimTom User",
    val authorAvatar: String = "",
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val likesCount: Int = 0
)
