package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.CommentEntity
import com.example.data.model.ReelEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ReelDao {
    @Query("SELECT * FROM reels ORDER BY createdAt DESC")
    fun getAllReels(): Flow<List<ReelEntity>>

    @Query("SELECT * FROM reels")
    suspend fun getAllReelsList(): List<ReelEntity>

    @Query("SELECT * FROM reels WHERE isUserUploaded = 1 ORDER BY createdAt DESC")
    fun getUserUploadedReels(): Flow<List<ReelEntity>>

    @Query("SELECT * FROM reels WHERE id = :id LIMIT 1")
    suspend fun getReelById(id: String): ReelEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReel(reel: ReelEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReels(reels: List<ReelEntity>)

    @Update
    suspend fun updateReel(reel: ReelEntity)

    @Delete
    suspend fun deleteReel(reel: ReelEntity)

    @Query("SELECT COUNT(*) FROM reels")
    suspend fun getReelCount(): Int

    // Comments
    @Query("SELECT * FROM comments WHERE reelId = :reelId ORDER BY timestamp ASC")
    fun getCommentsForReel(reelId: String): Flow<List<CommentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertComment(comment: CommentEntity)

    @Query("DELETE FROM comments WHERE reelId = :reelId")
    suspend fun deleteCommentsForReel(reelId: String)
}
