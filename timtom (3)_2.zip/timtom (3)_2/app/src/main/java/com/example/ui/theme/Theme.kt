package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val TimTomDarkColorScheme = darkColorScheme(
    primary = TimTomCrimson,
    onPrimary = TimTomTextPrimary,
    primaryContainer = TimTomCrimsonDark,
    onPrimaryContainer = TimTomTextPrimary,
    secondary = TimTomCyan,
    onSecondary = TimTomBlack,
    background = TimTomDarkBg,
    onBackground = TimTomTextPrimary,
    surface = TimTomSurface,
    onSurface = TimTomTextPrimary,
    surfaceVariant = TimTomCardBg,
    onSurfaceVariant = TimTomTextSecondary,
    outline = TimTomBorder
)

private val TimTomLightColorScheme = lightColorScheme(
    primary = TimTomCrimson,
    onPrimary = TimTomTextPrimary,
    primaryContainer = TimTomCrimsonLight,
    onPrimaryContainer = TimTomBlack,
    secondary = TimTomCyan,
    onSecondary = TimTomBlack,
    background = TimTomDarkBg, // Keep immersive dark for video app experience
    onBackground = TimTomTextPrimary,
    surface = TimTomSurface,
    onSurface = TimTomTextPrimary,
    surfaceVariant = TimTomCardBg,
    onSurfaceVariant = TimTomTextSecondary,
    outline = TimTomBorder
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep signature TimTom brand colors
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) TimTomDarkColorScheme else TimTomLightColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = TimTomDarkBg.toArgb()
                window.navigationBarColor = TimTomDarkBg.toArgb()
                WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
                WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = false
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
